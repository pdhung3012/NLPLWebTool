package com.anycode.examples;



public class Ex81 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: read big integer from console
			
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}