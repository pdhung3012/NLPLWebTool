package com.anycode.examples;


public class Ex61 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: get thread group
			
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}