package com.anycode.examples;

public class Ex43 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: create panel and set layout to border

		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}