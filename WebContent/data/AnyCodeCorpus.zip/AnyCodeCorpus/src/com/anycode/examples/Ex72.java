package com.anycode.examples;

import java.awt.event.InputEvent;



public class Ex72 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			
			InputEvent keystroke=null;
			// NLPL:  get keystroke modifiers
		

		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}