package com.anycode.examples;

import java.io.File;



public class Ex1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			
			String fname="a.txt";
			String destination="b.txt";			
			// NLPL: copy file fname to destination
			
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}