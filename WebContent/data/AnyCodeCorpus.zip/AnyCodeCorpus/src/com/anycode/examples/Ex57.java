package com.anycode.examples;

import java.util.BitSet;


public class Ex57 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: create bit set and set its 5th element to true
		
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}