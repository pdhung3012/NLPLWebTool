package com.anycode.examples;



public class Ex55 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			Object o=new Double(3.14);
			// NLPL: write object o to file output stream "data.obj"
			
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}