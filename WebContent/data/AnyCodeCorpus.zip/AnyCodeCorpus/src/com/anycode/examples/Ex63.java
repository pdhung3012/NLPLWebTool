package com.anycode.examples;



public class Ex63 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: get screen size
			
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}