package com.anycode.examples;



public class Ex37 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: read utf from the file "text.txt"

		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}