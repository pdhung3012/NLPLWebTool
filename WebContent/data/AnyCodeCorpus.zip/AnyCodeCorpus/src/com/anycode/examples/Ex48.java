package com.anycode.examples;



public class Ex48 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: check file "text.txt" "read" permission
			
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}