package com.anycode.examples;



public class Ex58 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: accept request on port 80
			
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}