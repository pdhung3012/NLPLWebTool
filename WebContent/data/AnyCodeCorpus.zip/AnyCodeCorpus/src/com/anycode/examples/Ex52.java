package com.anycode.examples;



public class Ex52 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: is file "text.txt" data available

		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}