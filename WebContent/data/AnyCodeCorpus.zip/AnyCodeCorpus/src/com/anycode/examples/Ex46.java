package com.anycode.examples;



public class Ex46 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: write 2015 to data ouput stream "text.txt"

		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}