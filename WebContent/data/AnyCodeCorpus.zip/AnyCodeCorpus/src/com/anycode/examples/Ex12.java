package com.anycode.examples;



public class Ex12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: open connection "http://www.oracle.com/"
			
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}