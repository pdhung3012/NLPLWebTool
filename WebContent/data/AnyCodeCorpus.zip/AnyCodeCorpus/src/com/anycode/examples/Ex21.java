package com.anycode.examples;



public class Ex21 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: delete file "text.txt"

		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}