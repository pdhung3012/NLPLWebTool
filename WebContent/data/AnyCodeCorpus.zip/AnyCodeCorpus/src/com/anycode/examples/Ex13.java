package com.anycode.examples;



public class Ex13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: create socket "http://www.oracle.com/" 80

		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}