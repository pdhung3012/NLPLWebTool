package com.anycode.examples;



public class Ex25 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: read line by line file "text.txt"
//			FileUtils.readLines(new File("text.txt"));
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}