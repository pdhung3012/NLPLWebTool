package com.anycode.examples;

public class Ex42 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: set thread min priority

		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}