package com.anycode.examples;



public class Ex82 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL:  delete file "text.txt" when JVM terminates

		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}