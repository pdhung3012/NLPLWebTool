package com.anycode.examples;


public class Ex4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: make file "text.txt"

		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}