package com.anycode.examples;


public class Ex73 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL:  generate "RSA" private key
			
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}