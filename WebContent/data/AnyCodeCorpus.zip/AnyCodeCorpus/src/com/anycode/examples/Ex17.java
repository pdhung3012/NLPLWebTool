package com.anycode.examples;



public class Ex17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: does the file "text.txt" exist

		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}