package com.anycode.examples;



public class Ex23 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: is "text.txt" directory

		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}