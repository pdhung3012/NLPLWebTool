package com.anycode.examples;

public class Ex24 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: get thread stack trace

		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}