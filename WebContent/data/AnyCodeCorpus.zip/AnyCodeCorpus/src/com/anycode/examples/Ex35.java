package com.anycode.examples;



public class Ex35 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: move file "text1.txt" to "text2.txt"

		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}