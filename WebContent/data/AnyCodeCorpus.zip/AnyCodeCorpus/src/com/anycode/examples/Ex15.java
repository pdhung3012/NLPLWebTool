package com.anycode.examples;


public class Ex15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: set thread max priority

		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}