package com.anycode.examples;



public class Ex44 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			
			int[] array = {3,4,1,2};
			String result="";
			
			// NLPL: sort array
			
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}