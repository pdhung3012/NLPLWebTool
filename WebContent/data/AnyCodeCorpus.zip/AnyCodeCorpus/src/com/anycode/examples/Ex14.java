package com.anycode.examples;

public class Ex14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: put a pair "Mike" , "+41-345-89-23" into a map

		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}