package com.anycode.examples;



public class Ex26 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: set time zone to "GMT"
			
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}