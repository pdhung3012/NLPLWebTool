package com.anycode.examples;

public class Ex20 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: join threads

		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}