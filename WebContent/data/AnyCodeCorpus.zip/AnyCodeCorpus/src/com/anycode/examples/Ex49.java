package com.anycode.examples;



public class Ex49 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: read lines with numbers from file "text.txt"
			
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}