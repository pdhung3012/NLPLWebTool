package com.anycode.examples;


public class Ex80 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			
			// NLPL:  set cursor over label to hand

		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}