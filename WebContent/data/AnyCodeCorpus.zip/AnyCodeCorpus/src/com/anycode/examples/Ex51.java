package com.anycode.examples;



public class Ex51 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: read from console
			
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}