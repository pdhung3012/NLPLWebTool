package com.anycode.examples;



public class Ex9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: new buffered reader "text.txt"
			
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}