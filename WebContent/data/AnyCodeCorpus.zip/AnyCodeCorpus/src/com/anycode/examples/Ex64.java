package com.anycode.examples;



public class Ex64 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: get splash screen graphics
			
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}