package com.anycode.examples;

import java.io.File;


public class Ex82 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL:  delete file ”text.txt” when JVM terminates
//			new File("text.txt").deleteOnExit();
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}