package com.anycode.examples;

import java.util.Properties;


public class Ex16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: set property ”gate.home” to value ”http://gate.ac.uk/”
//			new Properties().setProperty("gate.home", "http://gate.ac.uk/");
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}