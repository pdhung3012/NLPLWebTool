package com.anycode.examples;

import java.util.ArrayList;
import java.util.Collections;


public class Ex77 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			ArrayList<String> list=new ArrayList<String>();
			list.add("red");
			list.add("blue");
			list.add("green");
			
			// NLPL: reverse list
//			Collections.reverse(list);
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}