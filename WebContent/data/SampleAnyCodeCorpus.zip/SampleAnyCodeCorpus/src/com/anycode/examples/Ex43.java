package com.anycode.examples;
import java.awt.BorderLayout;
import java.awt.Panel;

public class Ex43 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: create panel and set layout to border
//			new Panel().setLayout(new BorderLayout());
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}