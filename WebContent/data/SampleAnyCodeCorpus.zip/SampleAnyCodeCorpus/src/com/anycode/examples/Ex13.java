package com.anycode.examples;

import java.net.Socket;


public class Ex13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: create socket ”http://www.oracle.com/” 80
			new Socket("http://www.oracle.com/", 80);
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}