package com.anycode.examples;

import java.awt.DisplayMode;
import java.awt.GraphicsEnvironment;


public class Ex68 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			
//			DisplayMode displayMode=GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().getDisplayMode();
			
			// NLPL: get display refresh rate
//			displayMode.getRefreshRate();
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}