package com.anycode.examples;

import java.security.KeyPairGenerator;


public class Ex73 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL:  generate ”RSA” private key
//			KeyPairGenerator.getInstance("RSA").generateKeyPair().getPrivate();
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}