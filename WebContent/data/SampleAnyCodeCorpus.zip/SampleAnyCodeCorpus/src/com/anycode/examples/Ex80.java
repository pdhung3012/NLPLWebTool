package com.anycode.examples;

import java.awt.Cursor;
import java.awt.Label;


public class Ex80 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			Label label=new Label("label1");
			
			// NLPL:  set cursor over label to hand
//			label.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}