package com.anycode.examples;

import java.io.DataInputStream;
import java.io.FileInputStream;


public class Ex52 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: is file ”text.txt” data available
//			new DataInputStream(new FileInputStream("text.txt")).available();
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}