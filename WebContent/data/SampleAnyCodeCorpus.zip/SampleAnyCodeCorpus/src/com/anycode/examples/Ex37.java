package com.anycode.examples;

import java.io.DataInputStream;
import java.io.FileInputStream;


public class Ex37 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: read utf from the file ”text.txt”
//			new DataInputStream(new FileInputStream("text.txt")).readUTF();
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}