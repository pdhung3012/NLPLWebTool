package com.anycode.examples;

import java.io.BufferedReader;
import java.io.InputStreamReader;


public class Ex51 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: read from console
//			new BufferedReader(new InputStreamReader(System.in)).readLine();
//			 System.in.r;
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}