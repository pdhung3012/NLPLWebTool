package com.anycode.examples;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;


public class Ex9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: new buffered reader ”text.txt”
			
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}