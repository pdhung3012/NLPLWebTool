package com.anycode.examples;

import java.lang.Thread;

public class Ex61 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: get thread group
//			Thread.currentThread().getThreadGroup();
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}