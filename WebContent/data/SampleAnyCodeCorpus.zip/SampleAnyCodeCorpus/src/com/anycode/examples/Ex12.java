package com.anycode.examples;

import java.net.URL;


public class Ex12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: open connection ”http://www.oracle.com/”
//			new URL("http://www.oracle.com/").openConnection();
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}