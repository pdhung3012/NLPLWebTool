package com.anycode.examples;

import java.io.File;


public class Ex34 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: rename file ”text1.txt” to ”text2.txt”
//			new File("text1.txt").renameTo(new File("text2.txt"));
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}