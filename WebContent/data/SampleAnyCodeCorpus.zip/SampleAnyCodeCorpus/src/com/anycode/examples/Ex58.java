package com.anycode.examples;

import java.net.ServerSocket;


public class Ex58 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: accept request on port 80
//			new ServerSocket(80).accept();
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}