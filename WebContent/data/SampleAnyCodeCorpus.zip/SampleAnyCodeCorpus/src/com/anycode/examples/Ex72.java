package com.anycode.examples;

import java.awt.event.KeyEvent;

import javax.swing.KeyStroke;


public class Ex72 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			
//			KeyStroke keystroke=KeyStroke.getKeyStroke('A');
			
			// NLPL:  get keystroke modifiers
//			KeyEvent.getKeyModifiersText(keystroke.getModifiers());
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}