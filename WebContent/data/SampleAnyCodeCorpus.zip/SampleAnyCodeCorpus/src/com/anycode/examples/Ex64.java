package com.anycode.examples;

import java.awt.SplashScreen;


public class Ex64 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: get splash screen graphics
//			SplashScreen.getSplashScreen().createGraphics();
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}