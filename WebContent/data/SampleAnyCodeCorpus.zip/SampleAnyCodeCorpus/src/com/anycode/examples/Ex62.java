package com.anycode.examples;

import java.awt.GridBagLayout;
import java.awt.Panel;

public class Ex62 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: create panel and set layout to grid
//			new Panel().setLayout(new GridBagLayout());
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}
