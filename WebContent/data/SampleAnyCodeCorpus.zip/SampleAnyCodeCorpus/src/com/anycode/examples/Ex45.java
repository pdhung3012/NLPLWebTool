package com.anycode.examples;

import java.awt.Label;
import java.awt.Panel;


public class Ex45 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: add label ”Names:” to panel
//			new Panel().add(new Label("Names:"));
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}