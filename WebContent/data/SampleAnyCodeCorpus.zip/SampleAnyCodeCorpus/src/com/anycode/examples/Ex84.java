package com.anycode.examples;

import java.text.DateFormat;
import java.util.Locale;


public class Ex84 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL:  get date instance for Germany
//			DateFormat.getDateTimeInstance(DateFormat.MEDIUM,DateFormat.MEDIUM, Locale.GERMANY);
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}