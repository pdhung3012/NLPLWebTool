package com.anycode.examples;
import java.lang.Runtime;

public class Ex31 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: total memory
//			Runtime.getRuntime().totalMemory();
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}