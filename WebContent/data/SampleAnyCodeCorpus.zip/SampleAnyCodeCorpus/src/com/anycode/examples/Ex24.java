package com.anycode.examples;
import java.lang.Thread;

public class Ex24 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: get thread stack trace
//			Thread.currentThread().getStackTrace();
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}