package com.anycode.examples;
import java.lang.Thread;

public class Ex20 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: join threads
			Thread.currentThread().join();
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}