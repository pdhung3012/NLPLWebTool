package com.anycode.examples;
import java.lang.Double;

public class Ex54 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			String x="3.14";
			// NLPL: get double value x

		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}