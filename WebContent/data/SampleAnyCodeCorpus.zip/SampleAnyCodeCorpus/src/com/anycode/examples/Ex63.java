package com.anycode.examples;

import java.awt.Toolkit;


public class Ex63 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: get screen size
//			Toolkit.getDefaultToolkit().getScreenSize();
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}