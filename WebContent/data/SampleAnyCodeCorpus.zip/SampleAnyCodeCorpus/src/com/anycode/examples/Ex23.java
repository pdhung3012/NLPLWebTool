package com.anycode.examples;

import java.io.File;


public class Ex23 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: is ”text.txt” directory
			new File("text.txt").isDirectory();
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}