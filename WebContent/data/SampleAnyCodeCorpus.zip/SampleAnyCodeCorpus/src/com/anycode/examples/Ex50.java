package com.anycode.examples;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.StreamTokenizer;


public class Ex50 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: check file ”text.txt” ”read” permission
//			new StreamTokenizer(new BufferedReader(new FileReader("text.txt")));
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}