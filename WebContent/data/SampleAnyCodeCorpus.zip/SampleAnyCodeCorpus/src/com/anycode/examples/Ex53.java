package com.anycode.examples;

import java.io.FileInputStream;
import java.io.SequenceInputStream;


public class Ex53 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: read from console
//			new SequenceInputStream(new FileInputStream("text1.txt"),new FileInputStream("text2.txt"));
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}