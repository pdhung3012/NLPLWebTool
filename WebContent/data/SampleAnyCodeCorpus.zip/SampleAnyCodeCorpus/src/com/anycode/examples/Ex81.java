package com.anycode.examples;

import java.util.Scanner;


public class Ex81 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: read big integer from console
//			new Scanner(System.in).nextBigInteger();
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}