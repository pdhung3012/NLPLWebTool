package com.anycode.examples;

import java.lang.Exception;
import java.io.File;

public class Ex22 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			
			new File("a.txt");
		} catch(Exception ex){
			// NLPL: print exception ex stack trace
//			ex.printStackTrace();
		}
		
	}

}