package com.anycode.examples;

import java.io.File;


public class Ex4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: make file ”text.txt”
//			new File("???").createNewFile();
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}