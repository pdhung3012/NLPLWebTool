package com.anycode.examples;

import java.io.DataInputStream;
import java.io.FileInputStream;


public class Ex33 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: new data stream ”text.txt”
//			new DataInputStream(new FileInputStream("text.txt"));
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}