package com.anycode.examples;

import java.io.File;

import org.apache.commons.io.FileUtils;


public class Ex5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: write ”hello” to file ”text.txt”
			FileUtils.writeStringToFile(new File("text.txt"), "hello");
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}