package com.anycode.examples;

import java.io.File;

import org.apache.commons.io.FileDeleteStrategy;


public class Ex21 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: delete file ”text.txt”
//			new File("text.txt").delete();
//			FileDeleteStrategy.NORMAL.delete(new File( "/Users/hungphan/Desktop/abc.txt" ) );
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}