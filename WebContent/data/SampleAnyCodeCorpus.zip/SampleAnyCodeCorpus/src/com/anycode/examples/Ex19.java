package com.anycode.examples;
import java.lang.Thread;

public class Ex19 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: get thread id
//			Thread.currentThread().getId();
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}