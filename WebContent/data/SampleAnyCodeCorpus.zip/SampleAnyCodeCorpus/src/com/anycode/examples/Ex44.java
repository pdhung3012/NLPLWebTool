package com.anycode.examples;

import java.util.Arrays;


public class Ex44 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			
			int[] array = {3,4,1,2};
			String result="";
			
//			sort array
			Arrays.sort(array);
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}