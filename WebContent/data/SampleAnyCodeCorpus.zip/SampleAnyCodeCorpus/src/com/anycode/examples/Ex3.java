package com.anycode.examples;
import java.lang.ClassLoader;

public class Ex3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: load class ”MyClass.class”
			
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}