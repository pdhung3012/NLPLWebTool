package com.anycode.examples;

import java.util.Calendar;
import java.util.TimeZone;


public class Ex26 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: set time zone to ”GMT”
			
//			Calendar.getInstance().setTimeZone(TimeZone.getTimeZone("GMT"));
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}