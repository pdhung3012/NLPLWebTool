package com.anycode.examples;

import java.io.DataOutputStream;
import java.io.FileOutputStream;


public class Ex46 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: write 2015 to data ouput stream ”text.txt”
//			new DataOutputStream(new FileOutputStream("text.txt")).write(2015);
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}