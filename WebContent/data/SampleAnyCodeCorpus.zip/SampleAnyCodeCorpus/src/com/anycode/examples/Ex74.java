package com.anycode.examples;


public class Ex74 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL:  get keystroke modifiers
//			Class.forName("MyClass.class").getProtectionDomain().getCodeSource();
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}