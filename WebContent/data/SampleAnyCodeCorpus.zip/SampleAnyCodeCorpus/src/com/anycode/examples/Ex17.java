package com.anycode.examples;

import java.io.File;


public class Ex17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: does the file ”text.txt” exist
//			new File("text.txt").exists();
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}