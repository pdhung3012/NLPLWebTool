package com.anycode.examples;

import java.awt.Rectangle;


public class Ex79 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			
			// NLPL:  intersection of rectangle 4 5 with rectangle 3 2
//			new Rectangle(5, 4).intersection(new Rectangle(3, 2));
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}