package com.anycode.examples;

import java.io.File;
import java.util.Date;


public class Ex47 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: get date when file ”text.txt” was last time modified
//			new Date(new File("text.txt").lastModified()).getTime();
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}