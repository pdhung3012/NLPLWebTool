package com.anycode.examples;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;


public class Ex55 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			Object o=new Double(3.14);
			// NLPL: write object o to file output stream ”data.obj”
//			new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream("data.obj"))).writeObject(o);
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}