package com.anycode.examples;

import java.io.File;

import org.apache.commons.io.FileUtils;


public class Ex35 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			// NLPL: move file ”text1.txt” to ”text2.txt”
//			FileUtils.moveFile(new File("text1.txt"), new File("text2.txt"));
		} catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}